module.exports=[62057,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_training_page_actions_185cp0kcqg0v8.js.map