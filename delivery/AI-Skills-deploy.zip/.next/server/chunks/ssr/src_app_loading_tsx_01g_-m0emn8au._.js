module.exports=[2747,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function(){return(0,b.jsx)("div",{className:"loading-shell",role:"status","aria-label":"Loading page",children:(0,b.jsx)("div",{className:"loader"})})}])},25210,function(a){a.n(a.i(2747))}];

//# sourceMappingURL=src_app_loading_tsx_01g_-m0emn8au._.js.map