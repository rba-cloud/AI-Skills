:HL["/_next/static/chunks/1mnf_8yf9yd0c.css","style"]
:HC["/",""]
1:[["children",{"s":"__PAGE__","h":160}]]
0:{"b":"BvbwuFOZ5jlo-B7aG7L_9","t":{"t":{"s":"","h":84,"c":"$Q1"}}}
