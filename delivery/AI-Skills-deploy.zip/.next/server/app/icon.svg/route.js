var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.svg/route.js")
R.c("server/chunks/[externals]__17m6ccbmzlpoe._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_0dn7480wo_c3b._.js")
R.c("server/chunks/_next-internal_server_app_icon_svg_route_actions_1r2h_ubdhjtcp.js")
R.m(61233)
module.exports=R.m(61233).exports
