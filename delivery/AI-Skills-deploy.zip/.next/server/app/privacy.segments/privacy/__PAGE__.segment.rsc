1:"/_next/static/chunks/414mvainq73qs.js"
2:"LoadingBoundaryProvider"
3:I[39756,["$1"],"$2"]
4:"$Sreact.fragment"
5:I[2971,["$1"],"Header"]
6:I[39756,["$1"],"default"]
7:"/_next/static/chunks/2swrp-d_-fpmf.js"
8:I[58298,["$1","$7"],"default"]
9:I[37457,["$1"],"default"]
a:I[22016,["$1"],""]
b:I[5014,["$1"],"default"]
16:"ViewportBoundary"
17:I[97367,["$1"],"$16"]
18:"MetadataBoundary"
19:I[97367,["$1"],"$18"]
1a:"$Sreact.suspense"
:HL["/_next/static/chunks/1mnf_8yf9yd0c.css","style"]
d:X
10:X
10:C
11:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$4","c",{"children":[["$","section",null,{"className":"section-shell","children":["$","article",null,{"className":"site-container policy","children":[["$","p",null,{"className":"eyebrow-label","children":[["$","span",null,{}],"Policy"]}],["$","h1",null,{"children":"Privacy Policy"}],["$","p",null,{"className":"legal-placeholder","children":[["$","strong",null,{"children":"Draft placeholder:"}]," This policy must be reviewed and completed before any form begins storing personal information."]}],["$","h2",null,{"children":"Current website behavior"}],["$","p",null,{"children":"The current demonstration does not connect contact or training-interest forms to a database. It does not claim to save submitted details."}],["$","h2",null,{"children":"Future data collection"}],["$","p",null,{"children":"When a secure submission service is connected, this page will identify the information collected, why it is needed, how it is protected, how long it is retained, and how people can request access or deletion."}],"$L12","$L13"]}]}],null,"$L14"]}],"p":"$@15","v":null,"s":"$d"}}]]
e:[["children",{"s":"privacy","h":96,"d":{"r":["$","$4","c",{"children":[null,["$","$L6",null,{"parallelRouterKey":"children","template":["$","$L9",null,{}]}]]}],"p":"$@f","v":"$10","s":"$d"},"c":"$Q11"}]]
0:{"t":{"t":{"s":"","h":84,"d":{"r":["$","$L3",null,{"loading":[["$","div","l",{"className":"loading-shell","role":"status","aria-label":"Loading page","children":["$","div",null,{"className":"loader"}]}],[],null],"children":["$","$4","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1mnf_8yf9yd0c.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/414mvainq73qs.js","async":true}]],["$","html",null,{"lang":"en","children":["$","body",null,{"children":[["$","a",null,{"className":"skip-link","href":"#main-content","children":"Skip to content"}],["$","$L5",null,{}],["$","main",null,{"id":"main-content","children":["$","$L6",null,{"parallelRouterKey":"children","error":"$8","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/2swrp-d_-fpmf.js","async":true}]],"template":["$","$L9",null,{}],"notFound":[["$","section",null,{"className":"not-found","children":[["$","div",null,{"className":"code","children":"404"}],["$","h1",null,{"children":"This page is still off the map."}],["$","p",null,{"children":"Try a practical learning path or head back to the workspace."}],["$","div",null,{"className":"hero-actions","style":{"justifyContent":"center"},"children":[["$","$La",null,{"className":"primary-button","href":"/learn","children":"Explore learning"}],["$","$La",null,{"className":"secondary-button","href":"/","children":"Back home"}]]}]]}],[]]}]}],["$","footer",null,{"className":"site-footer","children":[["$","div",null,{"className":"site-container footer-top","children":[["$","div",null,{"className":"footer-lead","children":[["$","$La",null,{"className":"brand-mark","href":"/","aria-label":"AI Skills Academy home","children":[["$","span",null,{"className":"brand-orbit","aria-hidden":"true","children":[["$","i",null,{}],["$","i",null,{}],["$","i",null,{}]]}],["$","span",null,{"children":["AI Skills",["$","br",null,{}],["$","strong",null,{"children":"Academy"}]]}]]}],["$","p",null,{"children":"Practical AI education for people who want to make useful things, not just learn tool names."}]]}],["$","div",null,{"className":"footer-links","children":[["$","div",null,{"children":[["$","h2",null,{"children":"Explore"}],["$","$La",null,{"href":"/learn","children":"Learn AI"}],["$","$La",null,{"href":"/tools","children":"AI Tools"}],["$","$La",null,{"href":"/projects","children":"Projects"}],["$","$La",null,{"href":"/resources","children":"Resources"}]]}],["$","div",null,{"children":[["$","h2",null,{"children":"Academy"}],["$","$La",null,{"href":"/training","children":"Live Training"}],["$","$La",null,{"href":"/about","children":"About"}],["$","$La",null,{"href":"/contact","children":"Contact"}],["$","$La",null,{"href":"/insights","children":"Insights"}]]}],["$","div",null,{"children":[["$","h2",null,{"children":"Policies"}],["$","$La",null,{"href":"/privacy","children":"Privacy"}],["$","$La",null,{"href":"/terms","children":"Terms"}],["$","$La",null,{"href":"/refund-policy","children":"Refund policy"}]]}]]}]]}],["$","div",null,{"className":"site-container footer-bottom","children":[["$","p",null,{"children":["© ",2026," AI Skills Academy. Built for practical learners."]}],["$","$La",null,{"href":"/contact","children":["Start a conversation ",["$","$Lb",null,{"icon":{"name":"arrow-up-right","size":24,"node":[["path",{"d":"M7 7h10v10","key":"1tivn9"}],["path",{"d":"M7 17 17 7","key":"1vkiza"}]]},"size":16}]]}]]}]]}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Organization\",\"name\":\"AI Skills Academy\",\"url\":\"http://localhost:3000\",\"description\":\"Practical AI education for learners in Pakistan and beyond.\"}"}}]]}]}]]}]}],"p":"$@c","v":null,"s":"$d"},"c":"$Qe"},"h":{"r":["$","$4","h",{"children":[null,["$","$L17",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L19",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$1a",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Privacy Policy | AI Skills Academy"}],["$","meta","1",{"name":"description","content":"Practical AI education for work, learning, creativity, and business — built for learners in Pakistan and beyond."}],["$","meta","2",{"name":"robots","content":"index, follow"}],["$","meta","3",{"property":"og:title","content":"AI Skills Academy"}],["$","meta","4",{"property":"og:description","content":"Learn AI by actually using it."}],["$","meta","5",{"property":"og:locale","content":"en_PK"}],["$","meta","6",{"property":"og:type","content":"website"}],["$","meta","7",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","8",{"name":"twitter:title","content":"AI Skills Academy"}],["$","meta","9",{"name":"twitter:description","content":"Learn AI by actually using it."}],["$","link","10",{"rel":"icon","href":"/icon.svg?icon.36zrf0z95h3lw.svg","sizes":"any","type":"image/svg+xml"}],"$L1b"]}]}],null]}],"$L1c"]}],"p":"$@1d","v":null,"s":"$d"}},"a":"$@1e","u":"$@1f","b":"BvbwuFOZ5jlo-B7aG7L_9"}
20:I[97367,["$1"],"OutletBoundary"]
22:I[27201,["$1"],"IconMark"]
12:["$","h2",null,{"children":"Third-party services"}]
13:["$","p",null,{"children":"Links to external AI tools lead to their official websites. Their own privacy policies apply when you use those services."}]
14:["$","$L20",null,{"children":["$","$1a",null,{"name":"Next.MetadataOutlet","children":"$@21"}]}]
1b:["$","$L22","11",{}]
1c:["$","meta",null,{"name":"next-size-adjust","content":""}]
d:300
21:null
1f:true
d:C
1e:0
f:"$undefined"
c:"$undefined"
1d:"$undefined"
15:"$undefined"
